import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";

const SYSTEM = `你是「小归」，一名文物知识与保护修复综合辅助专家。你的工作包括：
一、文物知识问答：介绍文物历史背景、年代、地域、材质、结构、制作工艺与文化价值；涉及具体断代或来源时，说明证据与不确定性，不编造出处。
二、残损图像辅助观察：分析用户上传图片中可见的裂纹、缺失、断裂、剥落、腐蚀、变形、污染、虫蛀等现象；描述位置、形态、范围和可见程度。明确区分“图片可见事实”“可能原因”和“需现场检测确认的判断”。不能仅凭照片断定材质、年代、内部结构或病害成因。
三、修复方案辅助建议：先了解材质、尺寸、年代/来源、保存环境、病害情况、既往修复史和用户目标；提供修复目标、原则、前期检测、建议方法、材料适用性、工艺流程、风险控制和后期保存建议。若信息不足，先列出关键缺失信息并给出有条件的初步建议。
四、数字化保护：可建议摄影测量、三维扫描、结构光/激光扫描、数字建档、虚拟补全与可视化记录；明确数字复原不等于实物修复，推测部分必须标注。
必须遵循真实性、最小干预、材料相容性、可识别性、可再处理性及长期保护原则。不得鼓励用户自行对珍贵、脆弱或不稳定文物实施粘接、打磨、补配、清洗、除锈、上漆或化学处理。遇到严重病害、出土文物、国家级/高价值文物或结构不稳定情况，建议停止触碰并联系有资质的文物保护机构/专业人员。
回答风格：中文、专业、清晰、务实；避免空泛和过度确定。普通知识问题直接回答。修复问题优先使用：1文物信息 2可见病害 3初步判断及不确定性 4修复目标与原则 5建议检测 6辅助方案与流程 7风险提示 8保存建议。不要声称自己是持证修复师，不要把辅助意见包装成正式修复方案。`;

export async function POST(req: NextRequest) {
  try {
    const key = process.env.OPENAI_API_KEY;
    if (!key) return NextResponse.json({ error: "网站尚未配置 OPENAI_API_KEY。请网站管理员在部署平台添加 API Key。" }, { status: 503 });
    const body = await req.json();
    const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
    const input = messages.map((m: any) => {
      const content: any[] = [{ type: "input_text", text: String(m.content || "").slice(0, 6000) }];
      if (typeof m.image === "string" && /^data:image\/(png|jpeg|webp);base64,/.test(m.image)) {
        if (m.image.length > 11_200_000) throw new Error("图片过大，请压缩后重新上传。");
        content.push({ type: "input_image", image_url: m.image, detail: "high" });
      }
      return { role: m.role === "assistant" ? "assistant" : "user", content };
    });
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${key}` },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4.1", instructions: SYSTEM, input, max_output_tokens: 1800 })
    });
    const data = await upstream.json();
    if (!upstream.ok) return NextResponse.json({ error: data?.error?.message || "模型服务暂时不可用，请稍后重试。" }, { status: upstream.status });
    const reply = (data.output || []).flatMap((item: any) => item.content || []).filter((c: any) => c.type === "output_text").map((c: any) => c.text).join("\n").trim();
    return NextResponse.json({ reply: reply || "我暂时没有生成有效回复，请换一种方式提问。" });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "服务器处理请求时发生错误。" }, { status: 400 });
  }
}
