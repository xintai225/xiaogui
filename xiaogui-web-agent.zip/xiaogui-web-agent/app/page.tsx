"use client";
import { FormEvent, useRef, useState } from "react";

type Message = { role: "user" | "assistant"; content: string; image?: string };
const starters = [
  { icon: "⌕", title: "文物知识问答", prompt: "请介绍一下中国古代木雕的主要工艺特点、常见材质和时代特征。" },
  { icon: "▧", title: "残损情况分析", prompt: "我想分析一件文物的残损情况，请告诉我需要提供哪些信息。" },
  { icon: "✧", title: "修复方案建议", prompt: "请介绍制定文物修复辅助方案时，需要遵循哪些原则和步骤。" },
  { icon: "◫", title: "数字化保护", prompt: "请为一件残损木质文物设计一套数字化记录与三维建档流程。" },
];
export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const send = async (e?: FormEvent, preset?: string) => {
    e?.preventDefault();
    const text = (preset ?? input).trim();
    if ((!text && !image) || busy) return;
    const userMessage: Message = { role: "user", content: text || "请分析我上传的文物图片。", image: image ?? undefined };
    const next = [...messages, userMessage];
    setMessages(next); setInput(""); setImage(null); setBusy(true); setError("");
    try {
      const res = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next.map(({role, content, image}) => ({role, content, image})) })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "请求失败，请稍后重试。");
      setMessages([...next, { role: "assistant", content: data.reply }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "连接失败，请检查网络或服务配置。");
    } finally { setBusy(false); }
  };
  const onFile = (f?: File) => {
    if (!f) return;
    if (!f.type.startsWith("image/")) { setError("请上传 JPG、PNG 或 WebP 图片。"); return; }
    if (f.size > 8 * 1024 * 1024) { setError("图片不能超过 8MB，请压缩后再上传。"); return; }
    const reader = new FileReader();
    reader.onload = () => setImage(String(reader.result));
    reader.readAsDataURL(f); setError("");
  };
  return <main className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="seal">归</div><div><b>小归</b><small>XIAOGUI · HERITAGE AI</small></div></div>
      <div className="side-label">智能服务</div>
      {starters.map((s,i)=><button className="side-link" key={i} onClick={()=>send(undefined,s.prompt)}><span>{s.icon}</span>{s.title}</button>)}
      <div className="side-note"><span className="dot"/> 在线辅助服务 <p>以科学保护为前提，让文物信息更清晰，让修复决策更有依据。</p></div>
      <div className="side-bottom">CULTURAL HERITAGE<br/>KNOWLEDGE & CONSERVATION</div>
    </aside>
    <section className="main">
      <header><div className="mobile-brand">小归 <span>文物知识与修复综合专家</span></div><div className="top-tag">文物知识 · 病害分析 · 保护修复</div><div className="avatar">归</div></header>
      <div className="conversation">
        {messages.length === 0 ? <div className="welcome">
          <div className="eyebrow">XIAOGUI / CULTURAL HERITAGE AI</div>
          <div className="welcome-seal">归</div>
          <h1>你好，我是小归。</h1>
          <p className="lead">让文物有迹可循，让历史重现光彩。</p>
          <p className="intro">我可以协助你了解文物历史、材质与传统工艺，分析图片中可见的残损现象，并提供审慎的保护修复思路。</p>
          <div className="starter-grid">{starters.map((s,i)=><button key={i} className="starter" onClick={()=>send(undefined,s.prompt)}><span>{s.icon}</span><b>{s.title}</b><small>{s.prompt}</small></button>)}</div>
          <div className="welcome-tip">你也可以上传文物照片，开始一次初步观察。</div>
        </div> : <div className="messages">{messages.map((m,i)=><div className={`message ${m.role}`} key={i}><div className="message-avatar">{m.role==="assistant"?"归":"我"}</div><div className="bubble"><div className="role-name">{m.role==="assistant"?"小归":"你"}</div>{m.image && <img className="uploaded" src={m.image} alt="上传的文物图片"/>}<div className="message-text">{m.content}</div></div></div>)}{busy&&<div className="message assistant"><div className="message-avatar">归</div><div className="bubble"><div className="role-name">小归</div><div className="typing"><i/><i/><i/> 正在整理分析…</div></div></div>}</div>}
        {error && <div className="error">{error}</div>}
      </div>
      <div className="composer-wrap">
        {image && <div className="image-preview"><img src={image} alt="待上传图片"/><button onClick={()=>setImage(null)}>移除 ×</button></div>}
        <form className="composer" onSubmit={send}>
          <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={e=>onFile(e.target.files?.[0])}/>
          <button type="button" className="attach" title="上传文物图片" onClick={()=>fileRef.current?.click()}>＋</button>
          <input value={input} onChange={e=>setInput(e.target.value)} placeholder="向小归提问，或描述文物的情况…" />
          <button className="send" type="submit" disabled={busy || (!input.trim()&&!image)}>发送 ↑</button>
        </form>
        <div className="disclaimer">小归提供知识与修复前期辅助建议，不替代文物保护专业人员的现场勘察、检测与正式修复决策。</div>
      </div>
    </section>
  </main>;
}
