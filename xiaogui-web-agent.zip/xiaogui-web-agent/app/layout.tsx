import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "小归｜文物知识与修复综合专家",
  description: "文物知识问答、残损图像辅助分析与保护修复建议。",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
